a = [1,2,3]
b = [6,5,4]
a.append(b)
print(a)